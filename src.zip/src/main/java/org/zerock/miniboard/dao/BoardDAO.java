package org.zerock.miniboard.dao;

import lombok.extern.log4j.Log4j2;
import org.zerock.miniboard.dto.BoardDTO;

@Log4j2
public enum BoardDAO {

    INSTANCE;

    private static final String SQL_INSERT = "insert into tbl_board (bno, count, title, writer, content) values (?, ?, ?, ?, ?)";


    public void insert(BoardDTO boardDTO) throws RuntimeException{

        new JdbcTemplate(){
            @Override
            protected void execute() throws Exception {
                int idx=1;
                preparedStatement = connection.prepareStatement(SQL_INSERT);
                preparedStatement.setLong(idx++, boardDTO.getBno());
                preparedStatement.setInt(idx++, boardDTO.getCount());
                preparedStatement.setString(idx++, boardDTO.getTitle());
                preparedStatement.setString(idx++, boardDTO.getWriter());
                preparedStatement.setString(idx++, boardDTO.getContent());

                preparedStatement.executeUpdate();
            }
        }.makeAll();



    }

}